import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: ('https://mail.google.com/mail/u/0?ui=2&ik=ab370ffd45&attid=0.1&permmsgid=msg-a:r4785223997706179845&th=18dc953570a0bb81&view=att&disp=safe&realattid=18dc9531a225820fe991'),
    name: 'Ann Analene Dela Cruz',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Andres Bonifacio Elementary School',
      elementaryYear: '2014',
      highSchool: 'Caloocan High School',
      highSchoolYear: '2018',
      college: 'Global Reciprocal Colleges',
    },
    about: 'I am Ann Analene Dela Cruz you can call me Ann, a 3rd year college in Global Reciprocal Colleges (GRC. I am the oldest in my family and I have one sister and two brothers. I live in Sangandaan Caloocan City. My hobbies are listening music, watching k-drama, playing online games and i also love to draw. My life from the beginning was very fun as i grew up living with my grandmother. I was very hyper and make a joke with my family. I am responsible and hardworking, so i study hard to obtain a good grades. I love to travel, i love to have fun and meet new people but I am a shy type person. I am good at drawing or sketching but I am not confident to show it to others. When i was child, my dream was to become a teacher.',
  projects:
    {
      projectName:'Lhenewin Party Shop Reservation System',
      imageSrc: 'https://mail.google.com/mail/u/0?ui=2&ik=ab370ffd45&attid=0.1&permmsgid=msg-f:1791472018217742421&th=18dc964f16ebb055&view=att&disp=safe&realattid=18dc964ac607ab1cef41',
      link: 'https://www.facebook.com/Lhenewinpartyss?mibextid=JRoKGi',
      description: 'Lhenewin Party Shop Reservation System aims to serve and to give high quality of services for their clients. The vision or the goal of the shop is to be a dynamic and progressive and to be known in terms of business. And the mission of the shop is to give satisfacting and ideal occasions for every client.',
    },

    contact: {
    mobile: '09125379358',
    email: 'annanalenedelacruz06@gmail.com',
    },
  };

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
        return 'education';
      case 'education':
        return 'about';
      case 'about':
        return 'projects'; // Move to the 'projects' section
      case 'projects':
        return 'contact'; // Move to the 'contact' section
      case 'contact':
        return 'name'; // Loop back to the start
      default:
        return 'name';
    }
  });
};

     return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.college}</Text>
                {' | '}
                {resumeData.education.collegeYear}
            
              <Text style={styles.projectTitle}>
                {'\n'}High School:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.highSchool}</Text>
                {' | '}
                {resumeData.education.highSchoolYear}
     
              <Text style={styles.projectTitle}>
                {'\n'}Elementary: 
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.elementary}</Text>
                {' | '}
                {resumeData.education.elementaryYear}
           
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>About me:{'\n'}</Text>
              <Text style={styles.about}>{resumeData.about}</Text>
            </View>
          )}

{currentSection === 'projects' && (
  <View style={styles.projectsContainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
    <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
    <Text style={styles.projectDescription}> {resumeData.projects.description}</Text>
  </View>
)}

{currentSection === 'projects1' && (
  <View style={styles.projectsContainer}>
     <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects1.projectName1}</Text>
    <Image source={{ uri: resumeData.projects1.imageSrc1 }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects1.link1}</Text>
    <Text style={styles.projectDescription}>{resumeData.projects1.description1}</Text>
  </View>
)}

          {currentSection === 'contact' && (
            <View style={styles.contactContainer}>
              <Text style={styles.header1}>Contact Me:{'\n'}</Text>
              <Text style={styles.info1}>
                {'\n'}Mobile: {resumeData.contact.mobile}
                {'\n'}Email: {resumeData.contact.email}
              </Text>
            </View>
          )}

        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  contentContainer: {
    alignItems: 'center',
    maxWidth: 600,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  textContainer: {
    alignSelf: 'stretch',
  },
  header: {
    fontSize: 27,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  header1: {
    fontSize: 27,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  info: {
    fontSize: 21,
    alignSelf: 'flex-start',
    textAlign: 'center',
  },
  info1: {
    fontSize: 21,
    alignSelf: 'flex-start',
    textAlign: 'left',

  },
  about: {
    fontSize: 17,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
   projectsContainer: {
    alignSelf: 'stretch',
    marginTop: 20,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  projectImage: {
    width: 230,
    height: 230,
    marginBottom: 10,
    alignSelf: 'center',
  },
  projectLink: {
    fontSize: 13,
    marginBottom: 5,
    textAlign: 'center',
  },
  projectDescription: {
    fontSize: 15,
    marginBottom: 10,
    textAlign: 'justify',
  },


});

export default App;